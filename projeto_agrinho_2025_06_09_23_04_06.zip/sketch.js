// Variáveis para os animais
let vacas = [];
let galinhas = [];
let porcos = [];
let ovelhas = [];
let árvores = [];
let cercado;

function setup() {
  createCanvas(1000, 600);

  // Inicializando os animais
  for (let i = 0; i < 3; i++) {
    vacas.push(new Vaca(random(500, 900), random(450, 550)));
    galinhas.push(new Galinha(random(500, 900), random(450, 550)));
    porcos.push(new Porco(random(500, 900), random(450, 550)));
    ovelhas.push(new Ovelha(random(500, 900), random(450, 550)));
  }

  // Inicializando árvores organizadas no chão
  for (let i = 0; i < 6; i++) {
    árvores.push(new Árvore(random(50, 950), random(400, 500)));
  }

  // Inicializando o cercado
  cercado = new Cerca(400, 400, 500, 150);
}

function draw() {
  // Fundo verde (agora mudado de azul para verde)
  background(34, 139, 34); // Cor verde para o fundo

  // Desenhando o fundo da fazenda
  desenharFazenda();

  // Desenhando as árvores no chão
  for (let arvore of árvores) {
    arvore.mostrar();
  }

  // Desenhando a cerca
  cercado.mostrar();

  // Desenhando e movendo os animais dentro do cercado
  for (let i = 0; i < vacas.length; i++) {
    vacas[i].mover();
    vacas[i].mostrar();
  }

  for (let i = 0; i < galinhas.length; i++) {
    galinhas[i].mover();
    galinhas[i].mostrar();
  }

  for (let i = 0; i < porcos.length; i++) {
    porcos[i].mover();
    porcos[i].mostrar();
  }

  for (let i = 0; i < ovelhas.length; i++) {
    ovelhas[i].mover();
    ovelhas[i].mostrar();
  }
}

// Função para desenhar o fundo da fazenda (montanhas, casa, etc.)
function desenharFazenda() {
  // Montanhas no fundo
  fill(139, 137, 112);
  triangle(0, 200, 300, 50, 600, 200); // Montanha esquerda
  triangle(300, 200, 600, 50, 1000, 200); // Montanha direita

  // Céu (agora estamos no fundo verde, então podemos usar nuvens brancas)
  fill(255, 255, 255, 200);
  ellipse(150, 100, 120, 60); // Nuvem
  ellipse(350, 80, 130, 70);  // Nuvem
  ellipse(800, 120, 100, 50);  // Nuvem
  
  // Casa simples no fundo da fazenda
  fill(255, 0, 0); // Casa vermelha
  rect(100, 300, 150, 150); // Corpo da casa
  triangle(100, 300, 250, 300, 175, 200); // Telhado

  // Janela e porta da casa
  fill(255);
  rect(125, 325, 40, 40); // Janela
  rect(175, 380, 30, 70); // Porta
}

// Função para desenhar o terreno (chão)
function desenharTerreno() {
  fill(34, 139, 34); // Cor do gramado
  noStroke();
  rect(0, height - 100, width, 100); // Terreno
}

// Classe para representar as vacas
class Vaca {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.velocidade = random(0.5, 1);
    this.direcao = 1;
  }

  mover() {
    this.x += this.velocidade * this.direcao;
    if (this.x > 850 || this.x < 500) {
      this.direcao *= -1;
    }
  }

  mostrar() {
    fill(255); // Corpo da vaca
    ellipse(this.x, this.y, 50, 50); // Corpo da vaca

    fill(0); // Olhos pretos
    ellipse(this.x - 15, this.y - 10, 10, 10); // Olho esquerdo
    ellipse(this.x + 15, this.y - 10, 10, 10); // Olho direito
  }
}

// Classe para representar as galinhas
class Galinha {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.velocidade = random(1, 1.5);
    this.direcao = 1;
  }

  mover() {
    this.x += this.velocidade * this.direcao;
    if (this.x > 850 || this.x < 500) {
      this.direcao *= -1;
    }
  }

  mostrar() {
    fill(255, 223, 0); // Corpo amarelo da galinha
    ellipse(this.x, this.y, 30, 30); // Corpo da galinha

    fill(255, 0, 0); // Crista vermelha
    triangle(this.x - 5, this.y - 10, this.x + 5, this.y - 10, this.x, this.y - 20);

    fill(0); // Olhos pretos
    ellipse(this.x - 8, this.y - 5, 5, 5); // Olho esquerdo
    ellipse(this.x + 8, this.y - 5, 5, 5); // Olho direito
  }
}

// Classe para representar os porcos
class Porco {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.velocidade = random(0.8, 1.2);
    this.direcao = 1;
  }

  mover() {
    this.x += this.velocidade * this.direcao;
    if (this.x > 850 || this.x < 500) {
      this.direcao *= -1;
    }
  }

  mostrar() {
    fill(255, 182, 193); // Corpo rosa do porco
    ellipse(this.x, this.y, 40, 40); // Corpo do porco

    fill(0); // Olhos pretos
    ellipse(this.x - 10, this.y - 5, 7, 7); // Olho esquerdo
    ellipse(this.x + 10, this.y - 5, 7, 7); // Olho direito

    fill(255, 105, 180); // Orelhas rosa
    triangle(this.x - 15, this.y - 20, this.x - 5, this.y - 30, this.x - 5, this.y - 10);
    triangle(this.x + 15, this.y - 20, this.x + 5, this.y - 30, this.x + 5, this.y - 10);
  }
}

// Classe para representar as ovelhas
class Ovelha {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.velocidade = random(0.5, 1);
    this.direcao = 1;
  }

  mover() {
    this.x += this.velocidade * this.direcao;
    if (this.x > 850 || this.x < 500) {
      this.direcao *= -1;
    }
  }

  mostrar() {
    fill(255); // Corpo da ovelha
    ellipse(this.x, this.y, 50, 50); // Corpo da ovelha

    fill(0); // Olhos pretos
    ellipse(this.x - 15, this.y - 10, 10, 10); // Olho esquerdo
    ellipse(this.x + 15, this.y - 10, 10, 10); // Olho direito

    fill(255); // Ovelha fofinha
    ellipse(this.x, this.y + 10, 30, 30); // Cabeça fofinha
  }
}

// Classe para representar as árvores no chão
class Árvore {
  constructor(x, y) {
    this.x = x;
    this.y = y;
  }

  mostrar() {
    fill(139, 69, 19); // Tronco da árvore
    rect(this.x - 10, this.y, 20, 60); // Tronco

    fill(34, 139, 34); // Folhagem verde
    ellipse(this.x, this.y - 20, 60, 60); // Copa da árvore
  }
}

// Classe para representar a cerca
class Cerca {
  constructor(x, y, largura, altura) {
    this.x = x;
    this.y = y;
    this.largura = largura;
    this.altura = altura;
  }

  mostrar() {
    stroke(139, 69, 19); // Cor da cerca
    line(this.x, this.y, this.x + this.largura, this.y); // Linha superior
    line(this.x, this.y + this.altura, this.x + this.largura, this.y + this.altura); // Linha inferior
    line(this.x, this.y, this.x, this.y + this.altura); // Linha esquerda
    line(this.x + this.largura, this.y, this.x + this.largura, this.y + this.altura); // Linha direita
  }
}